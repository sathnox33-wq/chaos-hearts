$function $(step)
