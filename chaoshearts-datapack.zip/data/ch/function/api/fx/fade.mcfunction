data modify entity @s interpolation_duration set value 3
data modify entity @s start_interpolation set value 0
data modify entity @s transformation.scale set value [0f,0f,0f]
