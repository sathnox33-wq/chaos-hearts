$function $(then)
